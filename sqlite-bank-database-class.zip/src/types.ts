export interface Account {
  acc_num: string;
  name: string;
  balance: number;
}

export interface Transaction {
  id: string;
  acc_num: string;
  type: 'deposit' | 'withdrawal' | 'transfer';
  amount: number;
  description: string;
  timestamp: Date;
  balanceAfter: number;
}
