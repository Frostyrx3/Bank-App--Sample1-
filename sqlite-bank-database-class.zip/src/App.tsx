import { useState, useCallback } from 'react';
import { Account } from './types';
import db from './bankDatabase';
import Dashboard from './components/Dashboard';
import AccountDetail from './components/AccountDetail';
import CreateAccount from './components/CreateAccount';
import CodeReview from './components/CodeReview';

type View = 'dashboard' | 'account' | 'create' | 'review';

export default function App() {
  const [view, setView] = useState<View>('dashboard');
  const [selectedAccount, setSelectedAccount] = useState<Account | null>(null);
  const [accounts, setAccounts] = useState<Account[]>(db.getAllAccounts());
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<string | null>(null);

  const refreshAccounts = useCallback(() => {
    setAccounts(db.getAllAccounts());
    if (selectedAccount) {
      const updated = db.getAccount(selectedAccount.acc_num);
      if (updated) setSelectedAccount(updated);
    }
  }, [selectedAccount]);

  const handleSelectAccount = (acc: Account) => {
    setSelectedAccount(acc);
    setView('account');
  };

  const handleDeleteAccount = (accNum: string) => {
    db.deleteAccount(accNum);
    refreshAccounts();
    setShowDeleteConfirm(null);
    if (selectedAccount?.acc_num === accNum) {
      setView('dashboard');
      setSelectedAccount(null);
    }
  };

  const handleResetDB = () => {
    db.resetDatabase();
    window.location.reload();
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-100 sticky top-0 z-50 shadow-sm">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <div className="flex items-center justify-between h-16">
            <button onClick={() => setView('dashboard')} className="flex items-center gap-3 hover:opacity-80 transition-opacity">
              <div className="w-9 h-9 bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl flex items-center justify-center">
                <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
                </svg>
              </div>
              <div>
                <h1 className="text-lg font-bold text-gray-800 leading-tight">BankDB</h1>
                <p className="text-[10px] text-gray-400 leading-tight">Code Review & Demo</p>
              </div>
            </button>

            <nav className="flex items-center gap-2">
              <button
                onClick={() => setView('review')}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  view === 'review' ? 'bg-purple-100 text-purple-700' : 'text-gray-500 hover:bg-gray-100'
                }`}
              >
                🔍 Code Review
              </button>
              <button
                onClick={() => setView('create')}
                className="px-4 py-2 rounded-lg text-sm font-medium bg-blue-600 text-white hover:bg-blue-700 transition-all flex items-center gap-1.5"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                </svg>
                New Account
              </button>
            </nav>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
        {view === 'dashboard' && (
          <>
            <Dashboard accounts={accounts} onSelectAccount={handleSelectAccount} />

            {/* Danger Zone */}
            {accounts.length > 0 && (
              <div className="mt-8 bg-white rounded-2xl shadow-sm border border-red-100 p-6">
                <h3 className="text-sm font-semibold text-red-600 uppercase tracking-wider mb-4">Danger Zone</h3>
                <div className="flex flex-wrap gap-3">
                  {accounts.map((acc) => (
                    <div key={acc.acc_num} className="relative">
                      {showDeleteConfirm === acc.acc_num ? (
                        <div className="flex items-center gap-2 bg-red-50 rounded-lg px-3 py-2 border border-red-200">
                          <span className="text-sm text-red-700">Delete {acc.name}?</span>
                          <button
                            onClick={() => handleDeleteAccount(acc.acc_num)}
                            className="text-xs bg-red-600 text-white px-2 py-1 rounded font-medium hover:bg-red-700"
                          >
                            Yes
                          </button>
                          <button
                            onClick={() => setShowDeleteConfirm(null)}
                            className="text-xs bg-gray-200 text-gray-700 px-2 py-1 rounded font-medium hover:bg-gray-300"
                          >
                            No
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => setShowDeleteConfirm(acc.acc_num)}
                          className="text-xs text-red-500 hover:text-red-700 hover:bg-red-50 px-3 py-2 rounded-lg border border-red-200 transition-all"
                        >
                          Delete {acc.acc_num}
                        </button>
                      )}
                    </div>
                  ))}
                  <button
                    onClick={handleResetDB}
                    className="text-xs text-red-500 hover:text-red-700 hover:bg-red-50 px-3 py-2 rounded-lg border border-red-200 transition-all ml-auto"
                  >
                    🗑 Reset All Data
                  </button>
                </div>
              </div>
            )}
          </>
        )}

        {view === 'account' && selectedAccount && (
          <AccountDetail
            account={selectedAccount}
            allAccounts={accounts}
            onBack={() => { setView('dashboard'); refreshAccounts(); }}
            onRefresh={refreshAccounts}
          />
        )}

        {view === 'create' && (
          <CreateAccount
            onCreated={() => { refreshAccounts(); setView('dashboard'); }}
            onCancel={() => setView('dashboard')}
          />
        )}

        {view === 'review' && (
          <CodeReview onBack={() => setView('dashboard')} />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-gray-100 bg-white mt-12">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-6 text-center text-sm text-gray-400">
          BankDB — Python SQLite Code Review & Interactive Demo • Built with React + TypeScript
        </div>
      </footer>
    </div>
  );
}
