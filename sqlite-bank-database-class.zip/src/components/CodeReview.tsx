export default function CodeReview({ onBack }: { onBack: () => void }) {
  const issues = [
    {
      severity: 'warning' as const,
      title: 'No close() method',
      line: 'class BankDatabase:',
      description: 'The database connection is never closed. Add a __del__ method or explicit close() method to properly release the SQLite connection.',
      fix: `def close(self):
    self.conn.close()

def __del__(self):
    self.close()`,
    },
    {
      severity: 'warning' as const,
      title: 'get_balance returns 0 for non-existent accounts',
      line: 'return result[0] if result else 0',
      description: 'Returning 0 for non-existent accounts can hide bugs. A non-existent account and an account with €0 balance are different things.',
      fix: `def get_balance(self, acc_num):
    self.cursor.execute("SELECT balance FROM accounts WHERE acc_num = ?", (acc_num,))
    result = self.cursor.fetchone()
    if result is None:
        raise ValueError(f"Account {acc_num} not found")
    return result[0]`,
    },
    {
      severity: 'warning' as const,
      title: 'update_balance has no existence check',
      line: 'def update_balance(self, acc_num, new_amount):',
      description: 'If the account does not exist, the UPDATE statement silently does nothing. No error is raised, and the caller has no way to know the update failed.',
      fix: `def update_balance(self, acc_num, new_amount):
    self.cursor.execute("UPDATE accounts SET balance = ? WHERE acc_num = ?", (new_amount, acc_num))
    if self.cursor.rowcount == 0:
        raise ValueError(f"Account {acc_num} not found")
    self.conn.commit()`,
    },
    {
      severity: 'info' as const,
      title: 'No deposit/withdraw methods',
      line: 'update_balance',
      description: 'Only a raw balance update method exists. Having dedicated deposit() and withdraw() methods would prevent accidental negative balances and provide transaction atomicity.',
      fix: `def deposit(self, acc_num, amount):
    if amount <= 0:
        raise ValueError("Amount must be positive")
    current = self.get_balance(acc_num)
    self.update_balance(acc_num, current + amount)

def withdraw(self, acc_num, amount):
    if amount <= 0:
        raise ValueError("Amount must be positive")
    current = self.get_balance(acc_num)
    if current < amount:
        raise ValueError("Insufficient funds")
    self.update_balance(acc_num, current - amount)`,
    },
    {
      severity: 'info' as const,
      title: 'No transaction history',
      line: 'CREATE TABLE IF NOT EXISTS accounts',
      description: 'There is no transactions table to track deposits, withdrawals, and transfers. This is essential for any banking application for auditing.',
      fix: `self.cursor.execute('''
    CREATE TABLE IF NOT EXISTS transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        acc_num TEXT,
        type TEXT,
        amount REAL,
        description TEXT,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (acc_num) REFERENCES accounts(acc_num)
    )
''')`,
    },
    {
      severity: 'success' as const,
      title: 'Parameterized queries ✓',
      line: 'WHERE acc_num = ?',
      description: 'Good practice! Using parameterized queries with ? placeholders prevents SQL injection attacks.',
      fix: '',
    },
    {
      severity: 'success' as const,
      title: 'IntegrityError handling ✓',
      line: 'except sqlite3.IntegrityError:',
      description: 'Properly catches duplicate primary key errors when trying to insert an existing account.',
      fix: '',
    },
  ];

  return (
    <div className="space-y-6">
      <button onClick={onBack} className="flex items-center gap-2 text-gray-500 hover:text-gray-800 transition-colors">
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
        </svg>
        Back to Dashboard
      </button>

      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-gray-800">Python Code Review</h1>
        <p className="text-gray-500 mt-2">Analysis of your BankDatabase class</p>
      </div>

      {/* Original Code */}
      <div className="bg-slate-800 rounded-2xl p-6 shadow-lg overflow-x-auto">
        <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-wider mb-4">Original Code</h3>
        <pre className="text-sm text-gray-300 leading-relaxed"><code>{`import sqlite3

class BankDatabase:
    def __init__(self):
        self.conn = sqlite3.connect('bank.db')
        self.cursor = self.conn.cursor()
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS accounts (
                acc_num TEXT PRIMARY KEY,
                name TEXT,
                balance REAL
            )
        ''')
        self.conn.commit()

    def get_balance(self, acc_num):
        self.cursor.execute(
            "SELECT balance FROM accounts WHERE acc_num = ?", (acc_num,)
        )
        result = self.cursor.fetchone()
        return result[0] if result else 0  `}<span className="text-yellow-400">⚠ Returns 0 for missing accounts</span>{`

    def update_balance(self, acc_num, new_amount):  `}<span className="text-yellow-400">⚠ No existence check</span>{`
        self.cursor.execute(
            "UPDATE accounts SET balance = ? WHERE acc_num = ?",
            (new_amount, acc_num)
        )
        self.conn.commit()

    def shto_përdorues(self, acc_num, emri, balanca_fillestare):
        try:
            self.cursor.execute(
                "INSERT INTO accounts VALUES (?, ?, ?)",
                (acc_num, emri, balanca_fillestare)
            )
            self.conn.commit()
        except sqlite3.IntegrityError:
            print("Llogaria ekziston!")  `}<span className="text-emerald-400">✓ Handles duplicates</span></code></pre>
      </div>

      {/* Issues */}
      <div className="space-y-4">
        {issues.map((issue, i) => (
          <div key={i} className={`bg-white rounded-2xl shadow-sm border overflow-hidden ${
            issue.severity === 'warning' ? 'border-amber-200' :
            issue.severity === 'info' ? 'border-blue-200' :
            'border-emerald-200'
          }`}>
            <div className={`px-6 py-4 flex items-start gap-3 ${
              issue.severity === 'warning' ? 'bg-amber-50' :
              issue.severity === 'info' ? 'bg-blue-50' :
              'bg-emerald-50'
            }`}>
              <span className="text-xl mt-0.5">
                {issue.severity === 'warning' ? '⚠️' : issue.severity === 'info' ? 'ℹ️' : '✅'}
              </span>
              <div className="flex-1">
                <h3 className="font-semibold text-gray-800">{issue.title}</h3>
                <p className="text-sm text-gray-600 mt-1">{issue.description}</p>
                <code className="text-xs bg-gray-800 text-gray-300 px-2 py-0.5 rounded mt-2 inline-block">{issue.line}</code>
              </div>
            </div>
            {issue.fix && (
              <div className="px-6 py-4 bg-gray-50 border-t border-gray-100">
                <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Suggested Fix</p>
                <pre className="text-sm text-emerald-700 bg-emerald-50 rounded-xl p-4 overflow-x-auto"><code>{issue.fix}</code></pre>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Summary */}
      <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl p-8 text-white">
        <h3 className="text-lg font-bold mb-4">📋 Summary</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-amber-500/20 rounded-xl p-4 text-center">
            <p className="text-3xl font-bold text-amber-400">3</p>
            <p className="text-sm text-amber-200">Warnings</p>
          </div>
          <div className="bg-blue-500/20 rounded-xl p-4 text-center">
            <p className="text-3xl font-bold text-blue-400">2</p>
            <p className="text-sm text-blue-200">Suggestions</p>
          </div>
          <div className="bg-emerald-500/20 rounded-xl p-4 text-center">
            <p className="text-3xl font-bold text-emerald-400">2</p>
            <p className="text-sm text-emerald-200">Good Practices</p>
          </div>
        </div>
      </div>
    </div>
  );
}
