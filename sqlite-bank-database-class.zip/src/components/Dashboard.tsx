import { Account } from '../types';
import db from '../bankDatabase';

interface DashboardProps {
  accounts: Account[];
  onSelectAccount: (acc: Account) => void;
}

export default function Dashboard({ accounts, onSelectAccount }: DashboardProps) {
  const totalBalance = db.getTotalBalance();
  const totalAccounts = accounts.length;
  const recentTransactions = db.getAllTransactions().slice(0, 5);

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        <div className="bg-gradient-to-br from-blue-600 to-blue-800 rounded-2xl p-6 text-white shadow-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-blue-200 text-sm font-medium">Total Balance</p>
              <p className="text-3xl font-bold mt-1">€{totalBalance.toLocaleString('en', { minimumFractionDigits: 2 })}</p>
            </div>
            <div className="bg-blue-500/30 rounded-xl p-3">
              <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-emerald-600 to-emerald-800 rounded-2xl p-6 text-white shadow-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-emerald-200 text-sm font-medium">Total Accounts</p>
              <p className="text-3xl font-bold mt-1">{totalAccounts}</p>
            </div>
            <div className="bg-emerald-500/30 rounded-xl p-3">
              <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
              </svg>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-purple-600 to-purple-800 rounded-2xl p-6 text-white shadow-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-purple-200 text-sm font-medium">Avg Balance</p>
              <p className="text-3xl font-bold mt-1">
                €{totalAccounts > 0 ? (totalBalance / totalAccounts).toLocaleString('en', { minimumFractionDigits: 2 }) : '0.00'}
              </p>
            </div>
            <div className="bg-purple-500/30 rounded-xl p-3">
              <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
              </svg>
            </div>
          </div>
        </div>
      </div>

      {/* Accounts Table */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-100">
          <h2 className="text-lg font-semibold text-gray-800">All Accounts</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-gray-50">
                <th className="text-left px-6 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Account #</th>
                <th className="text-left px-6 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Name</th>
                <th className="text-right px-6 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Balance</th>
                <th className="text-center px-6 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {accounts.map((acc) => (
                <tr key={acc.acc_num} className="hover:bg-blue-50/50 transition-colors cursor-pointer" onClick={() => onSelectAccount(acc)}>
                  <td className="px-6 py-4">
                    <span className="font-mono text-sm bg-gray-100 text-gray-700 px-2 py-1 rounded">{acc.acc_num}</span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center text-white font-bold text-sm">
                        {acc.name.charAt(0)}
                      </div>
                      <span className="font-medium text-gray-800">{acc.name}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <span className="font-semibold text-gray-900">€{acc.balance.toLocaleString('en', { minimumFractionDigits: 2 })}</span>
                  </td>
                  <td className="px-6 py-4 text-center">
                    <button
                      className="text-blue-600 hover:text-blue-800 text-sm font-medium hover:underline"
                      onClick={(e) => { e.stopPropagation(); onSelectAccount(acc); }}
                    >
                      View Details →
                    </button>
                  </td>
                </tr>
              ))}
              {accounts.length === 0 && (
                <tr>
                  <td colSpan={4} className="px-6 py-12 text-center text-gray-400">
                    No accounts found. Create one to get started.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Recent Transactions */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-100">
          <h2 className="text-lg font-semibold text-gray-800">Recent Transactions</h2>
        </div>
        <div className="divide-y divide-gray-50">
          {recentTransactions.map((txn) => {
            const account = db.getAccount(txn.acc_num);
            return (
              <div key={txn.id} className="px-6 py-4 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    txn.type === 'deposit' ? 'bg-emerald-100 text-emerald-600' :
                    txn.type === 'withdrawal' ? 'bg-red-100 text-red-600' :
                    'bg-blue-100 text-blue-600'
                  }`}>
                    {txn.type === 'deposit' ? (
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 11l5-5m0 0l5 5m-5-5v12" /></svg>
                    ) : txn.type === 'withdrawal' ? (
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 13l-5 5m0 0l-5-5m5 5V6" /></svg>
                    ) : (
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" /></svg>
                    )}
                  </div>
                  <div>
                    <p className="font-medium text-gray-800 text-sm">{txn.description}</p>
                    <p className="text-xs text-gray-400">{account?.name} • {new Date(txn.timestamp).toLocaleString()}</p>
                  </div>
                </div>
                <span className={`font-semibold ${txn.type === 'withdrawal' || (txn.type === 'transfer' && txn.description.startsWith('Transfer to')) ? 'text-red-600' : 'text-emerald-600'}`}>
                  {txn.type === 'withdrawal' || (txn.type === 'transfer' && txn.description.startsWith('Transfer to')) ? '-' : '+'}€{txn.amount.toLocaleString('en', { minimumFractionDigits: 2 })}
                </span>
              </div>
            );
          })}
          {recentTransactions.length === 0 && (
            <div className="px-6 py-12 text-center text-gray-400">No transactions yet.</div>
          )}
        </div>
      </div>
    </div>
  );
}
