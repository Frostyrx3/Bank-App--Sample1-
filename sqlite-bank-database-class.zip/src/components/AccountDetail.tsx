import { useState } from 'react';
import { Account } from '../types';
import db from '../bankDatabase';

interface AccountDetailProps {
  account: Account;
  allAccounts: Account[];
  onBack: () => void;
  onRefresh: () => void;
}

export default function AccountDetail({ account, allAccounts, onBack, onRefresh }: AccountDetailProps) {
  const [activeTab, setActiveTab] = useState<'transactions' | 'deposit' | 'withdraw' | 'transfer'>('transactions');
  const [amount, setAmount] = useState('');
  const [transferTo, setTransferTo] = useState('');
  const [message, setMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  const transactions = db.getTransactions(account.acc_num);
  const currentBalance = db.getBalance(account.acc_num) ?? 0;

  const showMessage = (text: string, type: 'success' | 'error') => {
    setMessage({ text, type });
    setTimeout(() => setMessage(null), 3000);
  };

  const handleDeposit = () => {
    const val = parseFloat(amount);
    if (isNaN(val) || val <= 0) {
      showMessage('Please enter a valid amount greater than 0', 'error');
      return;
    }
    if (db.deposit(account.acc_num, val)) {
      showMessage(`Successfully deposited €${val.toFixed(2)}`, 'success');
      setAmount('');
      onRefresh();
    } else {
      showMessage('Deposit failed', 'error');
    }
  };

  const handleWithdraw = () => {
    const val = parseFloat(amount);
    if (isNaN(val) || val <= 0) {
      showMessage('Please enter a valid amount greater than 0', 'error');
      return;
    }
    if (val > currentBalance) {
      showMessage('Insufficient funds', 'error');
      return;
    }
    if (db.withdraw(account.acc_num, val)) {
      showMessage(`Successfully withdrew €${val.toFixed(2)}`, 'success');
      setAmount('');
      onRefresh();
    } else {
      showMessage('Withdrawal failed', 'error');
    }
  };

  const handleTransfer = () => {
    const val = parseFloat(amount);
    if (isNaN(val) || val <= 0) {
      showMessage('Please enter a valid amount greater than 0', 'error');
      return;
    }
    if (!transferTo) {
      showMessage('Please select a recipient account', 'error');
      return;
    }
    if (db.transfer(account.acc_num, transferTo, val)) {
      const toAccount = db.getAccount(transferTo);
      showMessage(`Successfully transferred €${val.toFixed(2)} to ${toAccount?.name}`, 'success');
      setAmount('');
      setTransferTo('');
      onRefresh();
    } else {
      showMessage('Transfer failed. Check balance and recipient.', 'error');
    }
  };

  const otherAccounts = allAccounts.filter((a) => a.acc_num !== account.acc_num);

  return (
    <div className="space-y-6">
      {/* Back Button */}
      <button onClick={onBack} className="flex items-center gap-2 text-gray-500 hover:text-gray-800 transition-colors">
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
        </svg>
        Back to Dashboard
      </button>

      {/* Account Header */}
      <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl p-8 text-white shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-white/10 flex items-center justify-center text-2xl font-bold">
              {account.name.charAt(0)}
            </div>
            <div>
              <h1 className="text-2xl font-bold">{account.name}</h1>
              <p className="text-slate-400 font-mono text-sm">{account.acc_num}</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-slate-400 text-sm">Current Balance</p>
            <p className="text-4xl font-bold">€{currentBalance.toLocaleString('en', { minimumFractionDigits: 2 })}</p>
          </div>
        </div>
      </div>

      {/* Message */}
      {message && (
        <div className={`rounded-xl px-4 py-3 text-sm font-medium ${
          message.type === 'success' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-red-50 text-red-700 border border-red-200'
        }`}>
          {message.text}
        </div>
      )}

      {/* Tabs */}
      <div className="flex gap-1 bg-gray-100 rounded-xl p-1">
        {(['transactions', 'deposit', 'withdraw', 'transfer'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => { setActiveTab(tab); setAmount(''); setMessage(null); }}
            className={`flex-1 py-2.5 px-4 rounded-lg text-sm font-medium transition-all ${
              activeTab === tab ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            {tab.charAt(0).toUpperCase() + tab.slice(1)}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      {activeTab === 'transactions' && (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-100">
            <h2 className="font-semibold text-gray-800">Transaction History</h2>
          </div>
          <div className="divide-y divide-gray-50">
            {transactions.map((txn) => (
              <div key={txn.id} className="px-6 py-4 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
                    txn.type === 'deposit' ? 'bg-emerald-100 text-emerald-600' :
                    txn.type === 'withdrawal' ? 'bg-red-100 text-red-600' :
                    'bg-blue-100 text-blue-600'
                  }`}>
                    {txn.type === 'deposit' ? (
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 11l5-5m0 0l5 5m-5-5v12" /></svg>
                    ) : txn.type === 'withdrawal' ? (
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 13l-5 5m0 0l-5-5m5 5V6" /></svg>
                    ) : (
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" /></svg>
                    )}
                  </div>
                  <div>
                    <p className="font-medium text-gray-800 text-sm">{txn.description}</p>
                    <p className="text-xs text-gray-400">{new Date(txn.timestamp).toLocaleString()}</p>
                  </div>
                </div>
                <div className="text-right">
                  <span className={`font-semibold ${
                    txn.type === 'withdrawal' || (txn.type === 'transfer' && txn.description.startsWith('Transfer to')) ? 'text-red-600' : 'text-emerald-600'
                  }`}>
                    {txn.type === 'withdrawal' || (txn.type === 'transfer' && txn.description.startsWith('Transfer to')) ? '-' : '+'}€{txn.amount.toLocaleString('en', { minimumFractionDigits: 2 })}
                  </span>
                  <p className="text-xs text-gray-400">Bal: €{txn.balanceAfter.toLocaleString('en', { minimumFractionDigits: 2 })}</p>
                </div>
              </div>
            ))}
            {transactions.length === 0 && (
              <div className="px-6 py-12 text-center text-gray-400">No transactions for this account.</div>
            )}
          </div>
        </div>
      )}

      {(activeTab === 'deposit' || activeTab === 'withdraw') && (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8 max-w-md mx-auto">
          <h2 className="text-xl font-semibold text-gray-800 mb-6">
            {activeTab === 'deposit' ? '💰 Make a Deposit' : '💸 Make a Withdrawal'}
          </h2>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-600 mb-1.5">Amount (€)</label>
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00"
                min="0"
                step="0.01"
                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 outline-none text-lg transition-all"
              />
            </div>
            {activeTab === 'withdraw' && (
              <p className="text-sm text-gray-500">Available balance: <span className="font-semibold text-gray-800">€{currentBalance.toLocaleString('en', { minimumFractionDigits: 2 })}</span></p>
            )}
            <button
              onClick={activeTab === 'deposit' ? handleDeposit : handleWithdraw}
              className={`w-full py-3 rounded-xl font-semibold text-white transition-all ${
                activeTab === 'deposit' ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-red-600 hover:bg-red-700'
              }`}
            >
              {activeTab === 'deposit' ? 'Deposit' : 'Withdraw'}
            </button>
          </div>
        </div>
      )}

      {activeTab === 'transfer' && (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8 max-w-md mx-auto">
          <h2 className="text-xl font-semibold text-gray-800 mb-6">🔄 Transfer Funds</h2>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-600 mb-1.5">Recipient Account</label>
              <select
                value={transferTo}
                onChange={(e) => setTransferTo(e.target.value)}
                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 outline-none transition-all"
              >
                <option value="">Select an account...</option>
                {otherAccounts.map((acc) => (
                  <option key={acc.acc_num} value={acc.acc_num}>
                    {acc.name} ({acc.acc_num})
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-600 mb-1.5">Amount (€)</label>
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00"
                min="0"
                step="0.01"
                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 outline-none text-lg transition-all"
              />
            </div>
            <p className="text-sm text-gray-500">Available balance: <span className="font-semibold text-gray-800">€{currentBalance.toLocaleString('en', { minimumFractionDigits: 2 })}</span></p>
            <button
              onClick={handleTransfer}
              className="w-full py-3 rounded-xl font-semibold text-white bg-blue-600 hover:bg-blue-700 transition-all"
            >
              Transfer
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
