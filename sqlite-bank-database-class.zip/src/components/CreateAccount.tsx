import { useState } from 'react';
import db from '../bankDatabase';

interface CreateAccountProps {
  onCreated: () => void;
  onCancel: () => void;
}

export default function CreateAccount({ onCreated, onCancel }: CreateAccountProps) {
  const [name, setName] = useState('');
  const [initialBalance, setInitialBalance] = useState('');
  const [message, setMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  const generateAccountNumber = () => {
    const num = Math.floor(Math.random() * 900) + 100;
    return `ACC-${num}`;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!name.trim()) {
      setMessage({ text: 'Please enter a name', type: 'error' });
      return;
    }

    const balance = parseFloat(initialBalance);
    if (isNaN(balance) || balance < 0) {
      setMessage({ text: 'Please enter a valid initial balance', type: 'error' });
      return;
    }

    let accNum = generateAccountNumber();
    let attempts = 0;
    while (db.getAccount(accNum) && attempts < 100) {
      accNum = generateAccountNumber();
      attempts++;
    }

    if (db.addAccount(accNum, name.trim(), balance)) {
      setMessage({ text: `Account ${accNum} created successfully!`, type: 'success' });
      setTimeout(() => onCreated(), 1000);
    } else {
      setMessage({ text: 'Failed to create account. Account number may already exist.', type: 'error' });
    }
  };

  return (
    <div className="max-w-lg mx-auto">
      <button onClick={onCancel} className="flex items-center gap-2 text-gray-500 hover:text-gray-800 transition-colors mb-6">
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
        </svg>
        Back to Dashboard
      </button>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <svg className="w-8 h-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" />
            </svg>
          </div>
          <h2 className="text-2xl font-bold text-gray-800">Create New Account</h2>
          <p className="text-gray-500 mt-1">Fill in the details to open a new bank account</p>
        </div>

        {message && (
          <div className={`rounded-xl px-4 py-3 text-sm font-medium mb-6 ${
            message.type === 'success' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-red-50 text-red-700 border border-red-200'
          }`}>
            {message.text}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="block text-sm font-medium text-gray-600 mb-1.5">Account Holder Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Arben Hoxha"
              className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 outline-none transition-all"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-600 mb-1.5">Initial Balance (€)</label>
            <input
              type="number"
              value={initialBalance}
              onChange={(e) => setInitialBalance(e.target.value)}
              placeholder="0.00"
              min="0"
              step="0.01"
              className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 outline-none transition-all"
            />
          </div>
          <div className="flex gap-3 pt-2">
            <button
              type="button"
              onClick={onCancel}
              className="flex-1 py-3 rounded-xl font-semibold text-gray-700 bg-gray-100 hover:bg-gray-200 transition-all"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 py-3 rounded-xl font-semibold text-white bg-blue-600 hover:bg-blue-700 transition-all"
            >
              Create Account
            </button>
          </div>
        </form>
      </div>

      {/* Python Code Reference */}
      <div className="mt-8 bg-slate-800 rounded-2xl p-6 text-white shadow-lg">
        <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-wider mb-3">Original Python Equivalent</h3>
        <pre className="text-sm text-emerald-400 overflow-x-auto"><code>{`def shto_përdorues(self, acc_num, emri, balanca_fillestare):
    try:
        self.cursor.execute(
            "INSERT INTO accounts VALUES (?, ?, ?)",
            (acc_num, emri, balanca_fillestare)
        )
        self.conn.commit()
    except sqlite3.IntegrityError:
        print("Llogaria ekziston!")`}</code></pre>
      </div>
    </div>
  );
}
