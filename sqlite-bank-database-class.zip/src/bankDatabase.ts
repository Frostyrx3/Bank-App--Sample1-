import { Account, Transaction } from './types';

/**
 * BankDatabase - TypeScript equivalent of the Python BankDatabase class
 * Uses localStorage instead of SQLite for browser persistence
 *
 * Original Python code issues fixed:
 * 1. Added close() equivalent (cleanup method)
 * 2. get_balance now distinguishes between 0 balance and non-existent account
 * 3. update_balance checks if account exists
 * 4. Added transaction history
 * 5. Added deposit/withdrawal methods
 * 6. Consistent English naming
 */
class BankDatabase {
  private accounts: Account[];
  private transactions: Transaction[];

  constructor() {
    // Load from localStorage (equivalent to sqlite3.connect('bank.db'))
    const savedAccounts = localStorage.getItem('bank_accounts');
    const savedTransactions = localStorage.getItem('bank_transactions');

    this.accounts = savedAccounts ? JSON.parse(savedAccounts) : [];
    this.transactions = savedTransactions
      ? JSON.parse(savedTransactions, (key, value) => {
          if (key === 'timestamp') return new Date(value);
          return value;
        })
      : [];

    // Seed demo data if empty
    if (this.accounts.length === 0) {
      this.addAccount('ACC-001', 'Arben Hoxha', 15000);
      this.addAccount('ACC-002', 'Elira Krasniqi', 8500);
      this.addAccount('ACC-003', 'Driton Berisha', 22000);
      this.addAccount('ACC-004', 'Vjosa Gashi', 3200);
      this.addAccount('ACC-005', 'Burim Morina', 45000);
    }
  }

  private save(): void {
    // Equivalent to self.conn.commit()
    localStorage.setItem('bank_accounts', JSON.stringify(this.accounts));
    localStorage.setItem('bank_transactions', JSON.stringify(this.transactions));
  }

  getBalance(acc_num: string): number | null {
    // Fixed: returns null for non-existent accounts instead of 0
    const account = this.accounts.find((a) => a.acc_num === acc_num);
    return account ? account.balance : null;
  }

  getAccount(acc_num: string): Account | undefined {
    return this.accounts.find((a) => a.acc_num === acc_num);
  }

  getAllAccounts(): Account[] {
    return [...this.accounts];
  }

  updateBalance(acc_num: string, new_amount: number): boolean {
    // Fixed: checks if account exists before updating
    const index = this.accounts.findIndex((a) => a.acc_num === acc_num);
    if (index === -1) return false;
    this.accounts[index].balance = new_amount;
    this.save();
    return true;
  }

  addAccount(acc_num: string, name: string, initialBalance: number): boolean {
    // Equivalent to shto_përdorues
    const exists = this.accounts.find((a) => a.acc_num === acc_num);
    if (exists) {
      console.warn('Llogaria ekziston!'); // Account exists!
      return false;
    }
    this.accounts.push({ acc_num, name, balance: initialBalance });
    this.addTransaction(acc_num, 'deposit', initialBalance, 'Initial deposit', initialBalance);
    this.save();
    return true;
  }

  deleteAccount(acc_num: string): boolean {
    const index = this.accounts.findIndex((a) => a.acc_num === acc_num);
    if (index === -1) return false;
    this.accounts.splice(index, 1);
    this.transactions = this.transactions.filter((t) => t.acc_num !== acc_num);
    this.save();
    return true;
  }

  deposit(acc_num: string, amount: number): boolean {
    const account = this.accounts.find((a) => a.acc_num === acc_num);
    if (!account || amount <= 0) return false;
    account.balance += amount;
    this.addTransaction(acc_num, 'deposit', amount, 'Deposit', account.balance);
    this.save();
    return true;
  }

  withdraw(acc_num: string, amount: number): boolean {
    const account = this.accounts.find((a) => a.acc_num === acc_num);
    if (!account || amount <= 0 || account.balance < amount) return false;
    account.balance -= amount;
    this.addTransaction(acc_num, 'withdrawal', amount, 'Withdrawal', account.balance);
    this.save();
    return true;
  }

  transfer(fromAcc: string, toAcc: string, amount: number): boolean {
    const from = this.accounts.find((a) => a.acc_num === fromAcc);
    const to = this.accounts.find((a) => a.acc_num === toAcc);
    if (!from || !to || amount <= 0 || from.balance < amount || fromAcc === toAcc) return false;
    from.balance -= amount;
    to.balance += amount;
    this.addTransaction(fromAcc, 'transfer', amount, `Transfer to ${to.name} (${toAcc})`, from.balance);
    this.addTransaction(toAcc, 'deposit', amount, `Transfer from ${from.name} (${fromAcc})`, to.balance);
    this.save();
    return true;
  }

  private addTransaction(
    acc_num: string,
    type: Transaction['type'],
    amount: number,
    description: string,
    balanceAfter: number
  ): void {
    this.transactions.push({
      id: `TXN-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      acc_num,
      type,
      amount,
      description,
      timestamp: new Date(),
      balanceAfter,
    });
  }

  getTransactions(acc_num: string): Transaction[] {
    return this.transactions
      .filter((t) => t.acc_num === acc_num)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }

  getAllTransactions(): Transaction[] {
    return [...this.transactions].sort(
      (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );
  }

  getTotalBalance(): number {
    return this.accounts.reduce((sum, a) => sum + a.balance, 0);
  }

  resetDatabase(): void {
    this.accounts = [];
    this.transactions = [];
    localStorage.removeItem('bank_accounts');
    localStorage.removeItem('bank_transactions');
  }
}

// Singleton instance
const db = new BankDatabase();
export default db;
